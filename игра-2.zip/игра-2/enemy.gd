extends CharacterBody2D

@onready var player = get_parent().get_node('Player')
@onready var anim = $AnimatedSprite2D
@onready var game_over_scene = preload('res://lose.tscn')
	
func _physics_process(_delta):
	if not player:
		return

	var dir = (player.position - position).normalized()
	velocity = dir * 50
	move_and_slide()
	
	if velocity.x < 0:
		anim.flip_h = true
	elif velocity.x > 0:
		anim.flip_h = false

func _on_area_2d_body_entered(body: Node2D) -> void:
	# Проверяем, что столкновение произошло именно с игроком
	if body.name == "Player": 
		# Меняем текущую сцену на сцену проигрыша
		get_tree().change_scene_to_file("res://Lose.tscn")
